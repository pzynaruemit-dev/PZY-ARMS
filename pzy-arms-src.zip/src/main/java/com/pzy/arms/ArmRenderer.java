package com.pzy.arms;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.Items;

public final class ArmRenderer {
    private ArmRenderer() {}

    /** เงื่อนไขที่เราจะวาดแขนเอง (ถ้าไม่ใช่ ปล่อยให้เกมวาดตามปกติ) */
    public static boolean active(LocalPlayer player, PzyArmsConfig c) {
        if (player == null || !c.enabled || player.isInvisible()) return false;
        // ถือแผนที่: เกมวาดแขนคู่เองอยู่แล้ว
        return !(player.getMainHandItem().is(Items.FILLED_MAP) || player.getOffhandItem().is(Items.FILLED_MAP));
    }

    public static void renderBoth(PoseStack ps, MultiBufferSource buf, int light, LocalPlayer player, float pt, PzyArmsConfig c) {
        ArmMotion.update(player, pt, c);

        HumanoidArm mainArm = player.getMainArm();
        HumanoidArm offArm = mainArm == HumanoidArm.RIGHT ? HumanoidArm.LEFT : HumanoidArm.RIGHT;
        float swing = player.getAttackAnim(pt);
        boolean mainSwings = player.swingingArm == null || player.swingingArm == net.minecraft.world.InteractionHand.MAIN_HAND;

        renderArm(ps, buf, light, player, mainArm, mainSwings ? swing : 0f, c);
        if (c.showOffArm) {
            renderArm(ps, buf, light, player, offArm, mainSwings ? 0f : swing, c);
        }
    }

    private static void renderArm(PoseStack ps, MultiBufferSource buf, int light, LocalPlayer player,
                                  HumanoidArm side, float swing, PzyArmsConfig c) {
        boolean right = side != HumanoidArm.LEFT;
        float f = right ? 1f : -1f;
        float breath = right ? ArmMotion.breathR : ArmMotion.breathL;

        ps.pushPose();

        // 1) การเคลื่อนไหวมีชีวิต (ทั้งหมดรอบกล้อง)
        ps.translate(ArmMotion.walkX + ArmMotion.swayX,
                ArmMotion.walkY + ArmMotion.breathYAmp * breath + ArmMotion.lift,
                0.0);
        ps.mulPose(Axis.XP.rotationDegrees(ArmMotion.swayPitch + ArmMotion.walkPitch + ArmMotion.sprintPitch
                + ArmMotion.breathPitchAmp * breath + c.rotX));
        ps.mulPose(Axis.YP.rotationDegrees(ArmMotion.swayYaw + f * c.rotY));
        ps.mulPose(Axis.ZP.rotationDegrees(ArmMotion.walkRoll + f * c.rotZ));

        // 2) ท่าแขนพื้นฐาน (สไตล์เดียวกับแขนว่างของเกม) + แอนิเมชันตอนสวิง
        float s1 = Mth.sqrt(swing);
        float tx = -0.3f * Mth.sin(s1 * (float) Math.PI);
        float ty = 0.4f * Mth.sin(s1 * ((float) Math.PI * 2f));
        float tz = -0.4f * Mth.sin(swing * (float) Math.PI);
        ps.translate(f * (tx + 0.64000005f + c.offsetX), ty - 0.6f + c.offsetY, tz - 0.71999997f - c.offsetZ);
        ps.mulPose(Axis.YP.rotationDegrees(f * 45f));
        float s2 = Mth.sin(swing * swing * (float) Math.PI);
        float s3 = Mth.sin(s1 * (float) Math.PI);
        ps.mulPose(Axis.YP.rotationDegrees(f * s3 * 70f));
        ps.mulPose(Axis.ZP.rotationDegrees(f * s2 * -20f));
        ps.translate(f * -1f, 3.6f, 3.5f);
        ps.mulPose(Axis.ZP.rotationDegrees(f * 120f));
        ps.mulPose(Axis.XP.rotationDegrees(200f));
        ps.mulPose(Axis.YP.rotationDegrees(f * -135f));
        ps.translate(f * 5.6f, 0f, 0f);

        AbstractClientPlayer ap = player;
        PlayerRenderer renderer = (PlayerRenderer) Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(ap);
        if (right) {
            renderer.renderRightHand(ps, buf, light, ap);
        } else {
            renderer.renderLeftHand(ps, buf, light, ap);
        }

        ps.popPose();
    }
}
