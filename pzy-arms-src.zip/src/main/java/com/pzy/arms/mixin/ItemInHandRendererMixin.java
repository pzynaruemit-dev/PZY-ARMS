package com.pzy.arms.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pzy.arms.ArmRenderer;
import com.pzy.arms.PzyArmsConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.HumanoidArm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {

    /** วาดแขนของเราก่อนที่เกมจะวาดไอเทมในมือ (ไอเทมจะทับแขนเอง) */
    @Inject(method = "renderHandsWithItems", at = @At("HEAD"))
    private void pzyarms$drawArms(float partialTicks, PoseStack poseStack, MultiBufferSource.BufferSource buffer,
                                  LocalPlayer player, int light, CallbackInfo ci) {
        PzyArmsConfig cfg = PzyArmsConfig.get();
        if (ArmRenderer.active(player, cfg)) {
            ArmRenderer.renderBoth(poseStack, buffer, light, player, partialTicks, cfg);
        }
    }

    /** กันเกมวาดแขนซ้ำของเดิม (require = 0: ถ้าหาเมธอดไม่เจอ เกมจะไม่ล่ม แค่แขนซ้อนกัน) */
    @Inject(method = "renderPlayerArm", at = @At("HEAD"), cancellable = true, require = 0)
    private void pzyarms$cancelVanillaArm(PoseStack poseStack, MultiBufferSource buffer, int light,
                                          float equipProgress, float swingProgress, HumanoidArm side,
                                          CallbackInfo ci) {
        if (ArmRenderer.active(Minecraft.getInstance().player, PzyArmsConfig.get())) {
            ci.cancel();
        }
    }
}
