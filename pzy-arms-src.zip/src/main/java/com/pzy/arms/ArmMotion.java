package com.pzy.arms;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;

/** คำนวณการเคลื่อนไหว "มีชีวิต" ของแขนในแต่ละเฟรม (เก็บค่าไว้ใช้ทั้งสองแขน) */
public final class ArmMotion {
    // ผลลัพธ์ (หน่วย: ตำแหน่งเป็นหน่วยมุมมองกล้อง, มุมเป็นองศา)
    public static float breathR, breathL;       // -1..1
    public static float breathYAmp, breathPitchAmp;
    public static float walkX, walkY, walkRoll, walkPitch;
    public static float swayYaw, swayPitch, swayX;
    public static float lift;
    public static float sprintPitch;

    private static float sprintBlend, liftBlend, lastTime;

    private ArmMotion() {}

    public static void update(LocalPlayer p, float pt, PzyArmsConfig c) {
        float time = p.tickCount + pt;
        float dt = time - lastTime;
        if (dt < 0f || dt > 5f) dt = 0f;
        lastTime = time;
        float k = Mth.clamp(dt * 0.25f, 0f, 1f);

        // ---- วิ่ง (วิ่งเร็ว = ยกแขนลง/เอนไปข้างหน้านิดหน่อย) ----
        sprintBlend += ((p.isSprinting() ? 1f : 0f) - sprintBlend) * k;
        sprintPitch = sprintBlend * 6f * c.walkBob;

        // ---- เดิน (ใช้ค่าชุดเดียวกับที่เกมใช้โยกกล้อง) ----
        float wd = p.walkDist - p.walkDistO;
        float phase = -(p.walkDist + wd * pt) * (float) Math.PI;
        float amp = Mth.lerp(pt, p.oBob, p.bob);
        float boost = (1f + sprintBlend * 0.5f) * c.walkBob;
        walkX = Mth.sin(phase) * amp * 0.45f * boost;
        walkY = -Math.abs(Mth.cos(phase) * amp) * 0.55f * boost;
        walkRoll = Mth.sin(phase) * amp * 30f * boost;
        walkPitch = Math.abs(Mth.cos(phase - 0.2f) * amp) * 50f * boost;

        // ---- หายใจ (รอบละ ~4 วินาที, เบาลงตอนเดิน) ----
        float calm = 1f - Mth.clamp(amp * 8f, 0f, 0.8f);
        float w = 0.0785f;
        breathR = Mth.sin(time * w);
        breathL = Mth.sin(time * w + 0.9f);
        breathYAmp = 0.006f * calm * c.breathing;
        breathPitchAmp = 0.8f * calm * c.breathing;

        // ---- โยกตามการหมุนกล้อง (แขนหน่วงตามหลังหัวนิดหน่อย) ----
        float dy = Mth.wrapDegrees(p.getViewYRot(pt) - Mth.lerp(pt, p.yBobO, p.yBob));
        float dx = p.getViewXRot(pt) - Mth.lerp(pt, p.xBobO, p.xBob);
        swayYaw = Mth.clamp(dy * 0.12f, -12f, 12f) * c.sway;
        swayPitch = Mth.clamp(dx * 0.12f, -10f, 10f) * c.sway;
        swayX = Mth.clamp(-dy * 0.0015f, -0.05f, 0.05f) * c.sway;

        // ---- กระโดด/ตก (กระโดดแขนลง ตกแขนยก) ----
        double vy = p.getDeltaMovement().y;
        float target = Mth.clamp((float) (-(vy + 0.078) * 0.15), -0.08f, 0.08f);
        liftBlend += (target - liftBlend) * k;
        lift = liftBlend * c.jumpLift;
    }
}
