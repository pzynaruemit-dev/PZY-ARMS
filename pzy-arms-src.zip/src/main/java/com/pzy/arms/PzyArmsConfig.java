package com.pzy.arms;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * ค่าปรับแต่ง อ่านจากไฟล์ config/pzy-arms.json
 * แก้ไฟล์แล้วเซฟ ค่าจะโหลดใหม่เองในเกมภายใน ~1 วินาที (ไม่ต้องรีสตาร์ท)
 */
public final class PzyArmsConfig {
    public boolean enabled = true;
    /** แสดงแขนข้างที่ไม่ใช่มือหลักด้วย */
    public boolean showOffArm = true;

    /** ตัวคูณความแรงของแต่ละอนิเมชัน (0 = ปิด, 1 = ปกติ) */
    public float breathing = 1.0f;
    public float walkBob = 1.0f;
    public float sway = 1.0f;
    public float jumpLift = 1.0f;

    /** offsetX: + = ถ่างแขนออกด้านนอก, offsetY: + = ขึ้น, offsetZ: + = ไกลออกไปข้างหน้า */
    public float offsetX = 0.0f;
    public float offsetY = 0.0f;
    public float offsetZ = 0.0f;
    /** หมุนเพิ่ม (องศา) */
    public float rotX = 0.0f;
    public float rotY = 0.0f;
    public float rotZ = 0.0f;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static PzyArmsConfig current = new PzyArmsConfig();
    private static long lastModified = Long.MIN_VALUE;
    private static long nextCheck = 0L;

    public static PzyArmsConfig get() {
        long now = System.currentTimeMillis();
        if (now >= nextCheck) {
            nextCheck = now + 1000L;
            reloadIfChanged();
        }
        return current;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pzy-arms.json");
    }

    private static void reloadIfChanged() {
        Path path = file();
        try {
            if (!Files.exists(path)) {
                Files.createDirectories(path.getParent());
                Files.writeString(path, GSON.toJson(new PzyArmsConfig()), StandardCharsets.UTF_8);
            }
            long modified = Files.getLastModifiedTime(path).toMillis();
            if (modified == lastModified) {
                return;
            }
            lastModified = modified;
            PzyArmsConfig loaded = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), PzyArmsConfig.class);
            if (loaded != null) {
                current = loaded;
            }
        } catch (IOException | RuntimeException e) {
            // ไฟล์พัง/อ่านไม่ได้ -> ใช้ค่าเดิมต่อ
        }
    }
}
