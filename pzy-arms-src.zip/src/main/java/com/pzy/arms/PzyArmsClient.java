package com.pzy.arms;

import net.fabricmc.api.ClientModInitializer;

public class PzyArmsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // สร้างไฟล์ config/pzy-arms.json ตั้งแต่เปิดเกมครั้งแรก
        PzyArmsConfig.get();
    }
}
